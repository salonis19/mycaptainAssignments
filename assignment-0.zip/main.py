'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

x=10
y=1
while x>=0:
    print(x,',',y,',',end="")
    x=x-2
    y=y+2
