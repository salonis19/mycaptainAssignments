'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# Program make a simple calculator

# This function multiplies two numbers
def multiply(x, y):
    return x * y

# This function divides two numbers
def divide(x, y):
    return x / y

print("Select operation.")
print("1.Multiply")
print("2.Divide")

while True:
    # take input from the user
    choice = input("Enter choice(1/2): ")

    # check if choice is one of the two options
    if choice in ('1', '2'):
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))
        
        
        if choice == '1':
             print(num1, "*", num2, "=", multiply(num1, num2))

        elif choice == '2':
            print(num1, "/", num2, "=", divide(num1, num2))
            
        break
    
    else:
        print("Invalid Input")
